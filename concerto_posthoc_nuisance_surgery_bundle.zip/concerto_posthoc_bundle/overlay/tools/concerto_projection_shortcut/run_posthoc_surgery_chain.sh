#!/usr/bin/env bash
set -euo pipefail

# Minimal end-to-end helper for frozen-feature post-hoc editors.
# Usage example:
#   BACKBONE_CKPT=/path/to/model_last.pth \
#   REPO_ROOT=/path/to/concerto-shortcut-mvp \
#   METHOD=splice3d \
#   bash tools/concerto_projection_shortcut/run_posthoc_surgery_chain.sh

REPO_ROOT=${REPO_ROOT:-$(cd "$(dirname "$0")/../.." && pwd)}
CONFIG=${CONFIG:-semseg-ptv3-base-v1m1-0a-scannet-lin-proxy}
BACKBONE_CKPT=${BACKBONE_CKPT:?set BACKBONE_CKPT}
METHOD=${METHOD:-splice3d}
NUISANCE=${NUISANCE:-height+xyz}
OUTDIR=${OUTDIR:-${REPO_ROOT}/exp/posthoc/${METHOD}_${NUISANCE}}
ROWS_PER_SCENE=${ROWS_PER_SCENE:-16384}
TRAIN_PY=${TRAIN_PY:-${REPO_ROOT}/tools/train.py}
GPUS=${GPUS:-1}

mkdir -p "${OUTDIR}"

python "${REPO_ROOT}/tools/concerto_projection_shortcut/extract_frozen_backbone_features.py" \
  --repo-root "${REPO_ROOT}" \
  --config "${CONFIG}" \
  --weight "${BACKBONE_CKPT}" \
  --output-root "${OUTDIR}/cache" \
  --rows-per-scene "${ROWS_PER_SCENE}"

if [[ "${METHOD}" == "splice3d" ]]; then
  python "${REPO_ROOT}/tools/concerto_projection_shortcut/fit_splice3d_frozen.py" \
    --train-cache "${OUTDIR}/cache/train_features.pt" \
    --val-cache "${OUTDIR}/cache/val_features.pt" \
    --output "${OUTDIR}/splice3d_editor.pth" \
    --nuisance "${NUISANCE}"
  export POSTHOC_EDITOR_CKPT="${OUTDIR}/splice3d_editor.pth"
  export POSTHOC_BACKBONE_CKPT="${BACKBONE_CKPT}"
  python "${TRAIN_PY}" --config-file "${REPO_ROOT}/configs/concerto/semseg-ptv3-base-v1m1-0a-scannet-lin-splice3d-frozen.py" --num-gpus "${GPUS}"
else
  python "${REPO_ROOT}/tools/concerto_projection_shortcut/fit_hlns_frozen.py" \
    --train-cache "${OUTDIR}/cache/train_features.pt" \
    --val-cache "${OUTDIR}/cache/val_features.pt" \
    --output "${OUTDIR}/hlns_editor.pth" \
    --nuisance "${NUISANCE}"
  export POSTHOC_EDITOR_CKPT="${OUTDIR}/hlns_editor.pth"
  export POSTHOC_BACKBONE_CKPT="${BACKBONE_CKPT}"
  python "${TRAIN_PY}" --config-file "${REPO_ROOT}/configs/concerto/semseg-ptv3-base-v1m1-0a-scannet-lin-hlns-frozen.py" --num-gpus "${GPUS}"
fi
