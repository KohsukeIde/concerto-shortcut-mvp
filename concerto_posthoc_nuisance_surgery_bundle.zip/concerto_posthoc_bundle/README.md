# Concerto post-hoc nuisance surgery bundle

This bundle adds two frozen-feature post-training methods that plug into the current `KohsukeIde/concerto-shortcut-mvp` layout.

Included methods:

1. **SPLICE-3D (frozen-feature version)**
   - Fits a nuisance subspace from frozen Concerto point features.
   - Separates nuisance directions from a task basis using a task-safe residualization step.
   - Applies a global frozen projection to the final point feature before the linear segmentation head.

2. **Head-Localized Nuisance Surgery (HLNS)**
   - Fits nuisance/task scores on contiguous channel groups.
   - Selects the most nuisance-heavy groups and applies a block-diagonal frozen projection.
   - Because the current Pointcept linear-probe path exposes the final point feature tensor, not per-attention-head activations, this implementation uses **channel groups as a head proxy**.

## Files

- `overlay/pointcept/models/posthoc_nuisance_surgery.py`
  - `Splice3DEditor`
  - `HLNSEditor`
  - `PosthocEditedSegmentorV2`
- `overlay/tools/concerto_projection_shortcut/extract_frozen_backbone_features.py`
  - extracts frozen ScanNet features from a pretrained Concerto backbone.
- `overlay/tools/concerto_projection_shortcut/fit_splice3d_frozen.py`
  - fits a SPLICE-style frozen editor.
- `overlay/tools/concerto_projection_shortcut/fit_hlns_frozen.py`
  - fits a channel-group-localized frozen editor.
- `overlay/tools/concerto_projection_shortcut/run_posthoc_surgery_chain.sh`
  - extraction -> fit editor -> Pointcept linear-probe training.
- `overlay/configs/concerto/semseg-ptv3-base-v1m1-0a-scannet-lin-splice3d-frozen.py`
- `overlay/configs/concerto/semseg-ptv3-base-v1m1-0a-scannet-lin-hlns-frozen.py`

## Apply

```bash
bash apply_overlay.sh /path/to/concerto-shortcut-mvp
```

## Typical usage

### 1. SPLICE-3D

```bash
export REPO_ROOT=/path/to/concerto-shortcut-mvp
export BACKBONE_CKPT=/path/to/model_last.pth
export METHOD=splice3d
export NUISANCE=height+xyz
bash ${REPO_ROOT}/tools/concerto_projection_shortcut/run_posthoc_surgery_chain.sh
```

### 2. HLNS

```bash
export REPO_ROOT=/path/to/concerto-shortcut-mvp
export BACKBONE_CKPT=/path/to/model_last.pth
export METHOD=hlns
export NUISANCE=height+xyz
bash ${REPO_ROOT}/tools/concerto_projection_shortcut/run_posthoc_surgery_chain.sh
```

## Design notes

- The bundle is built to match the current Pointcept registry and ScanNet linear-probe flow.
- The new segmentor loads the pretrained backbone directly, so the linear-probe config does **not** need the `CheckpointLoader` hook.
- The editors are frozen affine transforms applied to the final point feature right before the segmentation head.
- `fit_*` scripts report a quick classifier-before/after proxy, but the intended acceptance test is still the standard Pointcept ScanNet linear probe.

## Suggested first experiments

1. `SPLICE-3D`, nuisance=`height+xyz`, gamma=`1.0`
2. `SPLICE-3D`, nuisance=`height`
3. `HLNS`, nuisance=`height+xyz`, `num_groups=16`, `topk=4`

## Validation status

The bundle was syntax-checked locally with `python -m py_compile` for the new Python files and `bash -n` for the launcher, but it was **not** executed end-to-end in your environment.
