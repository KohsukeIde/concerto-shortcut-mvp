import os

_base_ = ["./semseg-ptv3-base-v1m1-0a-scannet-lin-proxy.py"]

model = dict(
    type="PosthocEditedSegmentorV2",
    freeze_backbone=True,
    backbone_path=os.environ.get("POSTHOC_BACKBONE_CKPT", ""),
    keywords=os.environ.get("POSTHOC_BACKBONE_KEYWORDS", "module.student.backbone"),
    replacements=os.environ.get("POSTHOC_BACKBONE_REPLACEMENTS", "module.backbone"),
    editor_cfg=dict(
        type="HLNSEditor",
        feature_dim=1232,
        preserve_mean=True,
        num_groups=int(os.environ.get("POSTHOC_HLNS_GROUPS", "16")),
    ),
    editor_path=os.environ.get("POSTHOC_EDITOR_CKPT", ""),
    return_edit_metrics=True,
)

hooks = [
    dict(type="IterationTimer", warmup_iter=2),
    dict(type="InformationWriter"),
    dict(type="SemSegEvaluator"),
    dict(type="CheckpointSaver", save_freq=None),
    dict(type="PreciseEvaluator", test_last=False),
]
