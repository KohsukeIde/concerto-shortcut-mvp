#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then
  echo "Usage: $0 /path/to/concerto-shortcut-mvp" >&2
  exit 1
fi
TARGET="$1"
SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
OVERLAY="${SCRIPT_DIR}/overlay"
mkdir -p "${TARGET}"
cp -R "${OVERLAY}/." "${TARGET}/"
echo "[ok] overlay copied into ${TARGET}"
